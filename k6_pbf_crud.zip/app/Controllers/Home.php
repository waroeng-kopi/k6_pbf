<?php

namespace App\Controllers;

use App\Models\SewaModel; // Import the SewaModel

class Home extends BaseController
{
    public function index(): string
    {
        $data = [
            'title' => 'Home',
        ];
        return view('v_home', $data);
    }

    public function sewa()
    {
        $sewaModel = new SewaModel(); // Create instance of SewaModel
        $data = [
            'title' => 'Sewa Mobil',
            'isi_sewa' => $sewaModel->findAll(), // Retrieve data from database
        ];
        return view('v_sewa', $data);
    }

    public function mobil()
    {
        // Here you can similarly handle interaction with the mobil data if you have a model for it
        $data = [
            'title' => 'Daftar Mobil',
        ];
        return view('v_mobil', $data);
    }

    public function create()
    {
        // Validate form input
        $validation = \Config\Services::validation();
        $validation->setRules([
            // Define validation rules for input fields
            'namaMobil' => 'required',
            'penyewa' => 'required',
            'jamSewa' => 'required|numeric'
        ]);
        
        if (!$validation->withRequest($this->request)->run()) {
            // If validation fails, redirect back with validation errors
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        // If validation passes, insert the data into the database
        $sewaModel = new SewaModel();
        $data = [
            'namaMobil' => $this->request->getPost('namaMobil'),
            'penyewa' => $this->request->getPost('penyewa'),
            'jamSewa' => $this->request->getPost('jamSewa')
        ];
        $sewaModel->insert($data);

        // Redirect back to the view with a success message
        return redirect()->to('sewa')->with('success', 'Data berhasil ditambahkan.');
    }

}
