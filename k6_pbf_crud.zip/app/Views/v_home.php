<?php echo view('header') ?>

  <main class="min-h-screen" style="background-image: url('https://www.assarent.co.id/upload/image/home_1.png'); background-repeat: no-repeat; background-position: center; ">
    <div class="flex items-center h-screen">
      <h1 class="text-2xl text-bold w-fit m-auto mb-24">Sewa Mobil Bulakbanteng</h1>
    </div>
  </main>

  <?php echo view('footer') ?>